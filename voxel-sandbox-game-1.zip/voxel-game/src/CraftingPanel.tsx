import React, { useEffect, useState } from 'react';
import { RECIPES } from './game/constants';
import { getInventory, subscribeInventory } from './game/inventory';
import { craftItem, canCraft } from './game/crafting';
import { craftingOpen, setCraftingOpen, subscribeCrafting } from './game/game';

export default function CraftingPanel() {
  const [open, setOpen] = useState(craftingOpen);
  const [inventoryHash, setInventoryHash] = useState(0);

  useEffect(() => {
    return subscribeCrafting(setOpen);
  }, []);

  useEffect(() => {
    return subscribeInventory(() => {
      // Just a simple hash/toggle to force re-render
      setInventoryHash(h => h + 1);
    });
  }, []);

  if (!open) return null;

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      zIndex: 50,
      backgroundColor: 'rgba(0,0,0,0.85)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'white',
      fontFamily: 'sans-serif'
    }}>
      <div style={{
        width: '600px',
        maxWidth: '90%',
        maxHeight: '90%',
        backgroundColor: '#1E1E1E',
        borderRadius: '12px',
        padding: '24px',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '0 10px 25px rgba(0,0,0,0.5)',
        border: '1px solid #333'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2 style={{ margin: 0, fontSize: '24px', fontWeight: 'bold' }}>Crafting</h2>
          <button 
            onClick={() => setCraftingOpen(false)}
            style={{ 
              background: 'none', border: 'none', color: '#888', cursor: 'pointer', fontSize: '18px' 
            }}
          >
            ✕
          </button>
        </div>
        
        <div style={{ fontSize: '14px', color: '#AAA', marginBottom: '20px' }}>
          Press E to close
        </div>

        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {RECIPES.map(recipe => {
            const isCraftable = canCraft(recipe.id);
            return (
              <div key={recipe.id} style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                backgroundColor: '#2A2A2A',
                padding: '12px 16px',
                borderRadius: '8px',
                border: '1px solid #444'
              }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 'bold', fontSize: '16px', marginBottom: '4px' }}>{recipe.label}</div>
                  <div style={{ fontSize: '13px', color: '#AAA', display: 'flex', gap: '8px' }}>
                    {recipe.ingredients.map((ing, idx) => (
                      <span key={idx} style={{ color: canCraft(recipe.id) ? '#AAA' : '#FF6B6B' }}>
                        {ing.count}x {ing.item.replace('_', ' ')}
                      </span>
                    ))}
                  </div>
                </div>
                <button
                  disabled={!isCraftable}
                  onClick={() => craftItem(recipe.id)}
                  style={{
                    backgroundColor: isCraftable ? '#4CAF50' : '#444',
                    color: isCraftable ? 'white' : '#888',
                    border: 'none',
                    padding: '8px 16px',
                    borderRadius: '6px',
                    fontWeight: 'bold',
                    cursor: isCraftable ? 'pointer' : 'not-allowed',
                    opacity: isCraftable ? 1 : 0.5
                  }}
                >
                  Craft
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
