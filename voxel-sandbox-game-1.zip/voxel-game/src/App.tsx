import { useEffect, useRef, useState } from 'react';
import { initGame } from './game/game';
import Hotbar from './Hotbar';
import CraftingPanel from './CraftingPanel';
import InventoryBar from './InventoryBar';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isTouch, setIsTouch] = useState(false);
  const [webglError, setWebglError] = useState(false);

  useEffect(() => {
    setIsTouch('ontouchstart' in window);
    if (!canvasRef.current) return;

    let cleanup: (() => void) | undefined;
    
    initGame(canvasRef.current)
      .then(fn => {
        cleanup = fn;
      })
      .catch(err => {
        console.error('Failed to initialise game:', err);
        setWebglError(true);
      });

    const onLockChange = () => {
      setIsPlaying(document.pointerLockElement === canvasRef.current);
    };
    
    document.addEventListener('pointerlockchange', onLockChange);

    return () => {
      cleanup?.();
      document.removeEventListener('pointerlockchange', onLockChange);
    };
  }, []);

  // Shown only in environments without GPU/WebGL (e.g. server-side renderers).
  // Real browsers support WebGL and will never see this message.
  if (webglError) {
    return (
      <div style={{
        width: '100vw', height: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        background: '#1a1a2e', color: '#eee', fontFamily: 'monospace', textAlign: 'center', gap: 16,
      }}>
        <div style={{ fontSize: 48 }}>&#9888;</div>
        <div style={{ fontSize: 22, fontWeight: 'bold' }}>WebGL not available</div>
        <div style={{ fontSize: 14, color: '#aaa', maxWidth: 360 }}>
          Your browser or device does not support WebGL, which is required to run this 3D game.
          Try opening it in a modern desktop browser such as Chrome or Firefox.
        </div>
      </div>
    );
  }

  return (
    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', position: 'relative' }}>
      <canvas
        ref={canvasRef}
        style={{
          position: 'fixed',
          inset: 0,
          width: '100%',
          height: '100%',
          outline: 'none',
          touchAction: 'none'
        }}
      />

      {/* Crosshair — hidden on touch devices where the hotbar buttons are used */}
      {!isTouch && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          color: 'white',
          fontSize: '24px',
          userSelect: 'none',
          textShadow: '0 0 3px black',
          pointerEvents: 'none',
          zIndex: 10
        }}>
          +
        </div>
      )}

      {/* UI overlays */}
      <InventoryBar />
      <Hotbar />
      <CraftingPanel />

      {/* Click to Play overlay — desktop only, disappears on pointer lock */}
      {!isPlaying && !isTouch && (
        <div style={{
          position: 'absolute',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          pointerEvents: 'none',
          zIndex: 20,
        }}>
          <div style={{ fontSize: 32, fontWeight: 'bold', textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}>
            Click to Play
          </div>
          <div style={{ fontSize: 14, marginTop: 12, color: 'rgba(255,255,255,0.7)' }}>
            WASD to move &nbsp;|&nbsp; Space to jump &nbsp;|&nbsp; Left-click mine &nbsp;|&nbsp; Right-click place &nbsp;|&nbsp; 1..8 switch blocks &nbsp;|&nbsp; E for Crafting
          </div>
        </div>
      )}
    </div>
  );
}
