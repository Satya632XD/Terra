/**
 * Animated water plane surrounding the island. Purely visual (no collision):
 * depth-based color (shallow turquoise near the beach → deep blue further
 * out), animated ripples via a scrolling normal-ish sine displacement, and
 * a soft tint toward the current sky horizon color so it reads as a
 * reflection without needing an actual reflective render pass.
 */
import * as THREE from 'three';
import { CHUNK_MIN_X, CHUNK_MAX_X, CHUNK_MIN_Z, CHUNK_MAX_Z } from './constants';

const WATER_VERTEX_SHADER = /* glsl */ `
  uniform float time;
  varying vec2 vUv;
  varying float vWave;

  void main() {
    vUv = uv;
    vec3 pos = position;

    float wave =
      sin(pos.x * 0.35 + time * 1.1) * 0.10 +
      sin(pos.y * 0.45 - time * 0.8) * 0.08 +
      sin((pos.x + pos.y) * 0.22 + time * 0.5) * 0.06;

    pos.z += wave;
    vWave = wave;

    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
  }
`;

const WATER_FRAGMENT_SHADER = /* glsl */ `
  uniform vec3 shallowColor;
  uniform vec3 deepColor;
  uniform vec3 skyTint;
  uniform float centerRadius;
  uniform float falloffRadius;
  uniform float opacity;
  varying vec2 vUv;
  varying float vWave;

  void main() {
    // vUv spans 0..1 across the whole plane; distance from center (0.5,0.5)
    // approximates distance from the island, used to fade shallow -> deep.
    float dist = distance(vUv, vec2(0.5)) * 2.0; // 0 at center, ~1.4 at corners
    float depthT = clamp((dist - centerRadius) / max(falloffRadius, 0.001), 0.0, 1.0);

    vec3 base = mix(shallowColor, deepColor, depthT);

    // Blend toward the sky's horizon color for a cheap reflection feel,
    // stronger in the deep water where the surface acts more mirror-like.
    base = mix(base, skyTint, 0.18 + depthT * 0.22);

    // Subtle highlight along wave crests
    float highlight = smoothstep(0.06, 0.16, vWave) * 0.25;
    base += highlight;

    float alpha = mix(0.75, 0.92, depthT) * opacity;
    gl_FragColor = vec4(base, alpha);
  }
`;

export class Water {
  private mesh: THREE.Mesh;
  private material: THREE.ShaderMaterial;
  private elapsed = 0;

  constructor(scene: THREE.Scene, surfaceY: number) {
    const islandWidth = CHUNK_MAX_X - CHUNK_MIN_X + 1;
    const islandDepth = CHUNK_MAX_Z - CHUNK_MIN_Z + 1;
    // Extend the water well past the island so the horizon never shows bare void.
    const size = Math.max(islandWidth, islandDepth) * 8;

    const geometry = new THREE.PlaneGeometry(size, size, 96, 96);
    geometry.rotateX(-Math.PI / 2);

    this.material = new THREE.ShaderMaterial({
      vertexShader: WATER_VERTEX_SHADER,
      fragmentShader: WATER_FRAGMENT_SHADER,
      uniforms: {
        time: { value: 0 },
        shallowColor: { value: new THREE.Color('#4FD8C8') },
        deepColor: { value: new THREE.Color('#0B3D66') },
        skyTint: { value: new THREE.Color('#8FCBEA') },
        centerRadius: { value: (islandWidth / size) * 0.95 },
        falloffRadius: { value: 0.55 },
        opacity: { value: 1.0 },
      },
      transparent: true,
      side: THREE.DoubleSide,
    });

    this.mesh = new THREE.Mesh(geometry, this.material);
    this.mesh.position.set(
      (CHUNK_MIN_X + CHUNK_MAX_X) / 2 + 0.5,
      surfaceY,
      (CHUNK_MIN_Z + CHUNK_MAX_Z) / 2 + 0.5,
    );
    this.mesh.renderOrder = -1;
    scene.add(this.mesh);
  }

  /** Keep the reflection tint synced with the current sky horizon color. */
  setSkyTint(color: THREE.Color): void {
    (this.material.uniforms.skyTint.value as THREE.Color).copy(color);
  }

  update(delta: number): void {
    this.elapsed += delta;
    this.material.uniforms.time.value = this.elapsed;
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    this.material.dispose();
    if (this.mesh.parent) this.mesh.parent.remove(this.mesh);
  }
}
