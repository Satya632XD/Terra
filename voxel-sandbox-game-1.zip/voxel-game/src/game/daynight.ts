/**
 * Day/Night cycle: 7-minute day, 3-minute night (10-minute full cycle).
 * Drives the gradient sky dome, stars, sun/moon, and lighting. This is the
 * single source of truth for sky/horizon color — scene.fog is updated here
 * every frame from the same palette the sky shader uses, so they can never
 * drift apart.
 */
import * as THREE from 'three';
import { Sky, SkyPalette } from './sky';

const DAY_DURATION = 7 * 60;    // seconds
const NIGHT_DURATION = 3 * 60;  // seconds
const CYCLE_DURATION = DAY_DURATION + NIGHT_DURATION; // 600s

// Named palette keyframes across the day. Each has top/horizon/bottom sky
// colors plus ambient/sun light intensities and a warm-tint sun color.
interface Keyframe {
  t: number;
  top: string;
  horizon: string;
  bottom: string;
  ambient: number;
  sun: number;
  sunColor: string;
  stars: number;
}

const KEYFRAMES: Keyframe[] = [
  { t: 0.00, top: '#0B1330', horizon: '#3A2A4A', bottom: '#05070F', ambient: 0.12, sun: 0.15, sunColor: '#FF9E6B', stars: 0.5 }, // pre-dawn
  { t: 0.04, top: '#3E5B8A', horizon: '#FF9E6B', bottom: '#12141F', ambient: 0.35, sun: 0.55, sunColor: '#FFB27A', stars: 0.05 }, // sunrise
  { t: 0.10, top: '#3E7FD9', horizon: '#BFE3F5', bottom: '#1B2A3A', ambient: 0.6,  sun: 0.9,  sunColor: '#FFF3D0', stars: 0.0 }, // morning
  { t: 0.50, top: '#2E6FE0', horizon: '#8FCBEA', bottom: '#16283A', ambient: 0.62, sun: 0.95, sunColor: '#FFFBEF', stars: 0.0 }, // noon
  { t: 0.63, top: '#3E7FD9', horizon: '#BFE3F5', bottom: '#1B2A3A', ambient: 0.6,  sun: 0.85, sunColor: '#FFF0CE', stars: 0.0 }, // afternoon
  { t: 0.70, top: '#39406E', horizon: '#FF7043', bottom: '#140F1C', ambient: 0.32, sun: 0.5,  sunColor: '#FF7A42', stars: 0.05 }, // sunset
  { t: 0.76, top: '#141C3C', horizon: '#5A3A55', bottom: '#08060F', ambient: 0.15, sun: 0.08, sunColor: '#B85A6E', stars: 0.5 }, // dusk
  { t: 0.85, top: '#050914', horizon: '#12172B', bottom: '#020308', ambient: 0.06, sun: 0.0,  sunColor: '#8FA0E0', stars: 1.0 }, // night
  { t: 1.00, top: '#0B1330', horizon: '#3A2A4A', bottom: '#05070F', ambient: 0.12, sun: 0.15, sunColor: '#FF9E6B', stars: 0.5 }, // wrap to pre-dawn
];

function lerp(a: number, b: number, p: number): number {
  return a + (b - a) * p;
}

function findSegment(t: number): [Keyframe, Keyframe, number] {
  for (let i = 0; i < KEYFRAMES.length - 1; i++) {
    const a = KEYFRAMES[i];
    const b = KEYFRAMES[i + 1];
    if (t >= a.t && t <= b.t) {
      const p = b.t === a.t ? 0 : (t - a.t) / (b.t - a.t);
      return [a, b, p];
    }
  }
  const last = KEYFRAMES[KEYFRAMES.length - 1];
  return [last, last, 0];
}

export class DayNightCycle {
  private time = CYCLE_DURATION * 0.10; // start mid-morning
  private sky: Sky;
  private tmpColorA = new THREE.Color();
  private tmpColorB = new THREE.Color();
  private tmpSunA = new THREE.Color();
  private tmpSunB = new THREE.Color();
  private sunDir = new THREE.Vector3();
  private palette: SkyPalette = {
    top: new THREE.Color(),
    horizon: new THREE.Color(),
    bottom: new THREE.Color(),
  };

  constructor(
    private scene: THREE.Scene,
    private ambientLight: THREE.AmbientLight,
    private sunLight: THREE.DirectionalLight,
    private camera: THREE.Camera,
  ) {
    this.sky = new Sky(scene);
    this.scene.fog = new THREE.Fog(this.sky.horizonColor.getHex(), 25, 90);
  }

  update(delta: number): void {
    this.time = (this.time + delta) % CYCLE_DURATION;
    const t = this.time / CYCLE_DURATION;

    const [a, b, p] = findSegment(t);

    this.tmpColorA.set(a.top);
    this.tmpColorB.set(b.top);
    this.palette.top.copy(this.tmpColorA).lerp(this.tmpColorB, p);

    this.tmpColorA.set(a.horizon);
    this.tmpColorB.set(b.horizon);
    this.palette.horizon.copy(this.tmpColorA).lerp(this.tmpColorB, p);

    this.tmpColorA.set(a.bottom);
    this.tmpColorB.set(b.bottom);
    this.palette.bottom.copy(this.tmpColorA).lerp(this.tmpColorB, p);

    const ambientIntensity = lerp(a.ambient, b.ambient, p);
    const sunIntensity = lerp(a.sun, b.sun, p);
    const starOpacity = lerp(a.stars, b.stars, p);

    this.tmpSunA.set(a.sunColor);
    this.tmpSunB.set(b.sunColor);
    this.sunLight.color.copy(this.tmpSunA).lerp(this.tmpSunB, p);

    // Sun travels a full circle over the whole cycle; angle 0 = sunrise on horizon.
    const angle = (t - 0.05) * Math.PI * 2;
    this.sunDir.set(Math.cos(angle), Math.sin(angle), 0.35).normalize();

    this.sunLight.position.copy(this.sunDir).multiplyScalar(50);
    this.ambientLight.intensity = ambientIntensity;
    this.sunLight.intensity = sunIntensity;

    this.sky.update(t, this.sunDir, this.palette, starOpacity, this.camera.position);

    // Keep fog perfectly in sync with the sky's horizon color every frame,
    // mutating the existing Fog instance instead of allocating a new one.
    const fog = this.scene.fog as THREE.Fog;
    fog.color.copy(this.palette.horizon);
  }

  /** Returns 'day' | 'dusk' | 'night' | 'dawn' for UI display */
  getPhase(): string {
    const t = this.time / CYCLE_DURATION;
    if (t < 0.08 || t > 0.95) return 'dawn';
    if (t < 0.65) return 'day';
    if (t < 0.8) return 'dusk';
    return 'night';
  }

  getTimeString(): string {
    // Express as in-game time 6:00am (dawn) to 6:00am next day
    const hours = 6 + (this.time / CYCLE_DURATION) * 24;
    const h = Math.floor(hours % 24);
    const m = Math.floor((hours % 1) * 60);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  }

  /** Current horizon color, kept in sync with the sky and fog each frame. */
  getHorizonColor(): THREE.Color {
    return this.palette.horizon;
  }

  dispose(): void {
    this.sky.dispose();
  }
}
