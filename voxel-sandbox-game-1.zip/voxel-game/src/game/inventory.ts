/**
 * Inventory system: items, tools, held-tool state, durability.
 */

import { TOOL_DEFS } from './constants';

export interface InventoryItem {
  item: string;       // block type OR tool id OR 'raw_iron'|'iron_ingot'|'stick'|'planks'
  count: number;
  durability?: number; // current durability (tools only); undefined = not a tool
  maxDurability?: number;
}

// Singleton inventory store
const inventory: InventoryItem[] = [];
let heldToolIndex: number | null = null; // index in inventory of the equipped tool, or null

// Listeners for React UI updates
const listeners: Set<() => void> = new Set();
function notify() { listeners.forEach(fn => fn()); }

export function subscribeInventory(fn: () => void) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function getInventory(): InventoryItem[] { return inventory; }

export function getHeldToolIndex(): number | null { return heldToolIndex; }

export function getHeldTool(): InventoryItem | null {
  if (heldToolIndex === null) return null;
  return inventory[heldToolIndex] ?? null;
}

export function addItem(item: string, count: number, durability?: number, maxDurability?: number): void {
  const isTool = TOOL_DEFS[item] !== undefined;

  if (!isTool) {
    const existing = inventory.find(i => i.item === item);
    if (existing) {
      existing.count += count;
    } else {
      inventory.push({ item, count });
    }
  } else {
    // Tools don't stack
    for (let i = 0; i < count; i++) {
      inventory.push({ item, count: 1, durability, maxDurability });
    }
  }
  notify();
}

export function removeItem(item: string, count: number): boolean {
  if (!hasItem(item, count)) return false;
  
  let remaining = count;
  for (let i = inventory.length - 1; i >= 0; i--) {
    if (inventory[i].item === item) {
      if (inventory[i].count > remaining) {
        inventory[i].count -= remaining;
        remaining = 0;
        break;
      } else {
        remaining -= inventory[i].count;
        // If this is the held tool being removed, clear heldToolIndex
        if (heldToolIndex === i) {
          heldToolIndex = null;
        } else if (heldToolIndex !== null && heldToolIndex > i) {
          heldToolIndex--;
        }
        inventory.splice(i, 1);
      }
    }
    if (remaining === 0) break;
  }
  
  notify();
  return true;
}

export function equipTool(index: number | null): void {
  if (index !== null) {
    const item = inventory[index];
    if (item && TOOL_DEFS[item.item] !== undefined) {
      heldToolIndex = index;
    } else {
      heldToolIndex = null;
    }
  } else {
    heldToolIndex = null;
  }
  notify();
}

export function damageHeldTool(): void {
  if (heldToolIndex === null) return;
  const tool = inventory[heldToolIndex];
  if (tool && tool.durability !== undefined) {
    tool.durability--;
    if (tool.durability <= 0) {
      // Remove tool if broken
      inventory.splice(heldToolIndex, 1);
      heldToolIndex = null;
    }
    notify();
  }
}

export function hasItem(item: string, count: number): boolean {
  const total = inventory.filter(i => i.item === item).reduce((sum, i) => sum + i.count, 0);
  return total >= count;
}
