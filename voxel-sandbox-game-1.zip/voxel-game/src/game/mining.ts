/**
 * Timed block mining: tracks progress (0-1), applies tool speed,
 * tool tier gating, and durability decrement on successful break.
 */
import { BLOCK_HARDNESS, BLOCK_CATEGORY, BLOCK_REQUIRED_TIER, BLOCK_DROPS, TOOL_DEFS, ToolType } from './constants';
import { getHeldTool, addItem, damageHeldTool } from './inventory';
import * as THREE from 'three';

// Tool type → block category it gives bonus for
const TOOL_BONUS_CATEGORY: Record<ToolType, string> = {
  pickaxe: 'stone', axe: 'wood', shovel: 'dirt', sword: 'generic',
};

// Listeners for crack stage updates (used by renderer)
type MineListener = (progress: number, pos: THREE.Vector3 | null) => void;
const listeners: Set<MineListener> = new Set();
export function subscribeMining(fn: MineListener) { listeners.add(fn); return () => listeners.delete(fn); }

function notifyMining(progress: number, pos: THREE.Vector3 | null) {
  listeners.forEach(fn => fn(progress, pos));
}

interface MiningState {
  targetKey: string;    // "x,y,z"
  progress: number;     // 0 to 1
  blockType: string;
}

let state: MiningState | null = null;

export function updateMining(
  isHoldingMine: boolean,
  hitResult: { pos: THREE.Vector3; normal: THREE.Vector3 } | null,
  blockType: string,
  delta: number
): { mined: boolean; pos: THREE.Vector3 | null; droppedItem: string | null } {
  if (!isHoldingMine || !hitResult) {
    resetMining();
    return { mined: false, pos: null, droppedItem: null };
  }

  const hitKey = `${Math.floor(hitResult.pos.x)},${Math.floor(hitResult.pos.y)},${Math.floor(hitResult.pos.z)}`;

  if (!state || state.targetKey !== hitKey) {
    state = { targetKey: hitKey, progress: 0, blockType };
  }

  const hardness = BLOCK_HARDNESS[blockType as keyof typeof BLOCK_HARDNESS] ?? 1;
  const baseSpeed = hardness > 0 ? 1 / hardness : 1000;
  
  let effectiveSpeed = baseSpeed;
  const heldToolItem = getHeldTool();
  
  if (heldToolItem) {
    const toolDef = TOOL_DEFS[heldToolItem.item];
    if (toolDef) {
      const toolBonusCat = TOOL_BONUS_CATEGORY[toolDef.type];
      const blockCat = BLOCK_CATEGORY[blockType as keyof typeof BLOCK_CATEGORY];
      
      if (toolBonusCat === blockCat || (toolDef.type === 'sword' && blockType === 'leaves')) {
        effectiveSpeed *= toolDef.miningSpeed;
      }
    }
  }

  state.progress += effectiveSpeed * delta;
  
  notifyMining(state.progress, hitResult.pos);

  if (state.progress >= 1) {
    const reqTier = BLOCK_REQUIRED_TIER[blockType as keyof typeof BLOCK_REQUIRED_TIER];
    let canDrop = true;

    if (reqTier) {
      if (!heldToolItem || !TOOL_DEFS[heldToolItem.item]) {
        canDrop = false;
      } else {
        const toolMat = TOOL_DEFS[heldToolItem.item].material;
        if (reqTier === 'iron' && toolMat !== 'iron') canDrop = false;
        if (reqTier === 'stone' && toolMat === 'wood') canDrop = false;
      }
    }

    let droppedItem: string | null = null;
    if (canDrop) {
      const dropMapEntry = BLOCK_DROPS[blockType as keyof typeof BLOCK_DROPS];
      if (dropMapEntry === undefined) {
        droppedItem = blockType;
      } else {
        droppedItem = dropMapEntry;
      }
      if (blockType === 'iron_ore') droppedItem = 'raw_iron';
      if (blockType === 'diamond_ore') droppedItem = 'diamond';
    }

    if (heldToolItem && TOOL_DEFS[heldToolItem.item]) {
      damageHeldTool();
    }

    const pos = hitResult.pos.clone();
    resetMining();
    return { mined: true, pos, droppedItem };
  }

  return { mined: false, pos: null, droppedItem: null };
}

export function resetMining(): void {
  state = null;
  notifyMining(0, null);
}
