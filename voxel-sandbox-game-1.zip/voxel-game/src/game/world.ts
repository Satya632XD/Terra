/**
 * Voxel world state: 3D sparse map of blocks, add/remove APIs.
 */
import { BlockType, CHUNK_MIN_X, CHUNK_MAX_X, CHUNK_MIN_Z, CHUNK_MAX_Z } from './constants';
import { placeFeatures } from './worldgen';

const worldMap = new Map<string, BlockType>();

export function getBlockKey(x: number, y: number, z: number): string {
  return `${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
}

export function getBlock(x: number, y: number, z: number): BlockType | undefined {
  return worldMap.get(getBlockKey(x, y, z));
}

export function setBlock(x: number, y: number, z: number, type: BlockType): void {
  worldMap.set(getBlockKey(x, y, z), type);
}

export function removeBlock(x: number, y: number, z: number): void {
  worldMap.delete(getBlockKey(x, y, z));
}

// Distance (in blocks) from the island edge treated as beach/sand instead of grass.
const BEACH_WIDTH = 2;

export function generateWorld(): void {
  worldMap.clear();
  for (let x = CHUNK_MIN_X; x <= CHUNK_MAX_X; x++) {
    for (let z = CHUNK_MIN_Z; z <= CHUNK_MAX_Z; z++) {
      setBlock(x, -1, z, 'bedrock');
      setBlock(x, 0, z, 'stone');
      setBlock(x, 1, z, 'dirt');

      // Ring the island edge with sand so it reads as a beach against the water.
      const distFromEdge = Math.min(
        x - CHUNK_MIN_X, CHUNK_MAX_X - x,
        z - CHUNK_MIN_Z, CHUNK_MAX_Z - z,
      );
      setBlock(x, 2, z, distFromEdge < BEACH_WIDTH ? 'sand' : 'grass');
    }
  }
  placeFeatures();
}

export function getWorldMap(): Map<string, BlockType> {
  return worldMap;
}
