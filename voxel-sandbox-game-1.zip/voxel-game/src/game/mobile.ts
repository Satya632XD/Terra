/**
 * Touch controls for mobile devices.
 */
import { InputManager } from './input';

export function setupMobileControls(input: InputManager) {
  if (!input.isTouch) return () => {};

  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.inset = '0';
  container.style.pointerEvents = 'none';
  container.style.zIndex = '100';
  document.body.appendChild(container);

  // Left joystick base
  const joyBase = document.createElement('div');
  joyBase.style.position = 'absolute';
  joyBase.style.bottom = '40px';
  joyBase.style.left = '40px';
  joyBase.style.width = '120px';
  joyBase.style.height = '120px';
  joyBase.style.borderRadius = '50%';
  joyBase.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
  joyBase.style.pointerEvents = 'auto';
  joyBase.style.touchAction = 'none';
  container.appendChild(joyBase);

  // Left joystick knob
  const joyKnob = document.createElement('div');
  joyKnob.style.position = 'absolute';
  joyKnob.style.top = '30px';
  joyKnob.style.left = '30px';
  joyKnob.style.width = '60px';
  joyKnob.style.height = '60px';
  joyKnob.style.borderRadius = '50%';
  joyKnob.style.backgroundColor = 'rgba(255, 255, 255, 0.5)';
  joyBase.appendChild(joyKnob);

  let joyTouchId: number | null = null;
  const joyCenter = { x: 0, y: 0 };

  joyBase.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const touch = e.changedTouches[0];
    joyTouchId = touch.identifier;
    const rect = joyBase.getBoundingClientRect();
    joyCenter.x = rect.left + rect.width / 2;
    joyCenter.y = rect.top + rect.height / 2;
    updateJoy(touch);
  });

  joyBase.addEventListener('touchmove', (e) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joyTouchId) {
        updateJoy(e.changedTouches[i]);
      }
    }
  });

  const endJoy = (e: TouchEvent) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joyTouchId) {
        joyTouchId = null;
        joyKnob.style.transform = 'translate(0px, 0px)';
        input.moveJoystick.active = false;
        input.moveJoystick.dx = 0;
        input.moveJoystick.dy = 0;
      }
    }
  };

  joyBase.addEventListener('touchend', endJoy);
  joyBase.addEventListener('touchcancel', endJoy);

  function updateJoy(touch: Touch) {
    let dx = touch.clientX - joyCenter.x;
    let dy = touch.clientY - joyCenter.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxDist = 30;
    
    if (dist > maxDist) {
      dx = (dx / dist) * maxDist;
      dy = (dy / dist) * maxDist;
    }
    
    joyKnob.style.transform = `translate(${dx}px, ${dy}px)`;
    
    input.moveJoystick.active = true;
    input.moveJoystick.dx = dx / maxDist;
    input.moveJoystick.dy = dy / maxDist;
  }

  // Look area (right half of screen)
  const lookArea = document.createElement('div');
  lookArea.style.position = 'absolute';
  lookArea.style.top = '0';
  lookArea.style.right = '0';
  lookArea.style.width = '50%';
  lookArea.style.height = '100%';
  lookArea.style.pointerEvents = 'auto';
  lookArea.style.touchAction = 'none';
  container.appendChild(lookArea);

  let lookTouchId: number | null = null;
  let lastLookX = 0;
  let lastLookY = 0;

  lookArea.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const touch = e.changedTouches[0];
    lookTouchId = touch.identifier;
    lastLookX = touch.clientX;
    lastLookY = touch.clientY;
  });

  lookArea.addEventListener('touchmove', (e) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchId) {
        input.lookDelta.dx += touch.clientX - lastLookX;
        input.lookDelta.dy += touch.clientY - lastLookY;
        lastLookX = touch.clientX;
        lastLookY = touch.clientY;
      }
    }
  });

  const endLook = (e: TouchEvent) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchId) {
        lookTouchId = null;
      }
    }
  };

  lookArea.addEventListener('touchend', endLook);
  lookArea.addEventListener('touchcancel', endLook);

  // Buttons
  const createButton = (text: string, right: string, bottom: string, onDown: () => void, onUp?: () => void) => {
    const btn = document.createElement('div');
    btn.textContent = text;
    btn.style.position = 'absolute';
    btn.style.right = right;
    btn.style.bottom = bottom;
    btn.style.width = '60px';
    btn.style.height = '60px';
    btn.style.borderRadius = '50%';
    btn.style.backgroundColor = 'rgba(255, 255, 255, 0.3)';
    btn.style.display = 'flex';
    btn.style.alignItems = 'center';
    btn.style.justifyContent = 'center';
    btn.style.color = 'white';
    btn.style.fontWeight = 'bold';
    btn.style.pointerEvents = 'auto';
    btn.style.userSelect = 'none';
    btn.style.zIndex = '110';
    
    btn.addEventListener('touchstart', (e) => {
      e.preventDefault();
      onDown();
      btn.style.backgroundColor = 'rgba(255, 255, 255, 0.6)';
    });
    btn.addEventListener('touchend', (e) => {
      e.preventDefault();
      if (onUp) onUp();
      btn.style.backgroundColor = 'rgba(255, 255, 255, 0.3)';
    });
    container.appendChild(btn);
  };

  createButton('Mine', '100px', '120px', 
    () => { input.mineTriggered = true; input.isHoldingMine = true; },
    () => { input.isHoldingMine = false; }
  );
  createButton('Place', '20px', '120px', 
    () => { input.placeTriggered = true; input.isHoldingPlace = true; },
    () => { input.isHoldingPlace = false; }
  );
  createButton('Jump', '20px', '200px', 
    () => { input.keys['Space'] = true; },
    () => { input.keys['Space'] = false; }
  );
  createButton('Inv', '180px', '120px', 
    () => { input.craftingKeyTriggered = true; }
  );

  return () => {
    if (container.parentElement) {
      container.parentElement.removeChild(container);
    }
  };
}
