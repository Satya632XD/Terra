/**
 * Block type definitions, world size, and colors.
 */
export type BlockType =
  | 'grass' | 'dirt' | 'stone' | 'wood' | 'brick'
  | 'log' | 'leaves' | 'cobblestone' | 'iron_ore'
  | 'bedrock' | 'gravel' | 'sand' | 'diamond_ore';

export const BLOCK_COLORS: Record<BlockType, { top: string; side: string; bottom: string }> = {
  grass: { top: '#5A8A3C', side: '#7A5C3A', bottom: '#7A5C3A' },
  dirt:  { top: '#7A5C3A', side: '#7A5C3A', bottom: '#7A5C3A' },
  stone: { top: '#888888', side: '#888888', bottom: '#888888' },
  wood:  { top: '#C8A96E', side: '#8B6340', bottom: '#C8A96E' },
  brick: { top: '#B04030', side: '#B04030', bottom: '#B04030' },
  log: { top: '#C8A96E', side: '#6B4226', bottom: '#C8A96E' },
  leaves: { top: '#2D8A1F', side: '#2D8A1F', bottom: '#2D8A1F' },
  cobblestone: { top: '#9E9E9E', side: '#9E9E9E', bottom: '#9E9E9E' },
  iron_ore: { top: '#888888', side: '#888888', bottom: '#888888' },
  bedrock: { top: '#4A4A4A', side: '#4A4A4A', bottom: '#4A4A4A' },
  gravel: { top: '#8D8C8A', side: '#8D8C8A', bottom: '#8D8C8A' },
  sand: { top: '#E3D6A0', side: '#E3D6A0', bottom: '#E3D6A0' },
  diamond_ore: { top: '#888888', side: '#888888', bottom: '#888888' },
};

// Hotbar shows only these for placing:
export const HOTBAR_BLOCKS: BlockType[] = ['grass', 'log', 'cobblestone', 'wood', 'brick', 'leaves', 'sand', 'gravel'];

export const WORLD_SIZE = 32;
export const WORLD_HALF = WORLD_SIZE / 2;
export const CHUNK_MIN_X = -WORLD_HALF;
export const CHUNK_MAX_X = WORLD_HALF - 1;
export const CHUNK_MIN_Z = -WORLD_HALF;
export const CHUNK_MAX_Z = WORLD_HALF - 1;

// Tool material tiers
export type ToolMaterial = 'wood' | 'stone' | 'iron';
// Tool types
export type ToolType = 'pickaxe' | 'axe' | 'shovel' | 'sword';

export interface ToolDef {
  material: ToolMaterial;
  type: ToolType;
  durability: number;   // max uses
  miningSpeed: number;  // multiplier vs base speed
}

export const TOOL_DEFS: Record<string, ToolDef> = {
  wood_pickaxe:  { material: 'wood',  type: 'pickaxe', durability: 60,  miningSpeed: 2.0 },
  stone_pickaxe: { material: 'stone', type: 'pickaxe', durability: 130, miningSpeed: 4.0 },
  iron_pickaxe:  { material: 'iron',  type: 'pickaxe', durability: 250, miningSpeed: 8.0 },
  wood_axe:      { material: 'wood',  type: 'axe',     durability: 60,  miningSpeed: 2.0 },
  stone_axe:     { material: 'stone', type: 'axe',     durability: 130, miningSpeed: 4.0 },
  iron_axe:      { material: 'iron',  type: 'axe',     durability: 250, miningSpeed: 8.0 },
  wood_shovel:   { material: 'wood',  type: 'shovel',  durability: 60,  miningSpeed: 2.0 },
  stone_shovel:  { material: 'stone', type: 'shovel',  durability: 130, miningSpeed: 4.0 },
  iron_shovel:   { material: 'iron',  type: 'shovel',  durability: 250, miningSpeed: 8.0 },
  wood_sword:    { material: 'wood',  type: 'sword',   durability: 60,  miningSpeed: 1.0 },
  stone_sword:   { material: 'stone', type: 'sword',   durability: 130, miningSpeed: 1.0 },
  iron_sword:    { material: 'iron',  type: 'sword',   durability: 250, miningSpeed: 1.0 },
};

// Seconds to break with bare hands (0 = instant)
export const BLOCK_HARDNESS: Record<BlockType, number> = {
  grass: 0.9, dirt: 0.75, stone: 7.5, wood: 3.0, brick: 10.0,
  log: 3.0, leaves: 0.3, cobblestone: 10.0, iron_ore: 15.0,
  bedrock: Infinity, gravel: 0.9, sand: 0.75, diamond_ore: 18.0,
};

// Block category for tool bonus speed (pickaxe/axe/shovel matches = 3x speed)
export type BlockCategory = 'dirt' | 'stone' | 'wood' | 'generic';
export const BLOCK_CATEGORY: Record<BlockType, BlockCategory> = {
  grass: 'dirt', dirt: 'dirt',
  stone: 'stone', cobblestone: 'stone', iron_ore: 'stone', brick: 'stone',
  log: 'wood', leaves: 'wood', wood: 'wood',
  bedrock: 'stone', gravel: 'dirt', sand: 'dirt', diamond_ore: 'stone',
};

// Minimum tool tier required to drop items (null = any/bare hands)
export type ToolTier = null | 'wood' | 'stone' | 'iron';
export const BLOCK_REQUIRED_TIER: Record<BlockType, ToolTier> = {
  grass: null, dirt: null, log: null, leaves: null, wood: null,
  stone: 'wood', cobblestone: null, brick: 'wood', iron_ore: 'stone',
  bedrock: 'iron', gravel: null, sand: null, diamond_ore: 'iron',
};

// What block type to drop (undefined = same as block)
export const BLOCK_DROPS: Partial<Record<BlockType, BlockType | null>> = {
  stone: 'cobblestone',   // stone drops cobblestone (not silk touch)
  iron_ore: null,         // drops raw_iron ITEM, not a block
  diamond_ore: null,      // drops raw diamond ITEM, not a block
};

export interface Recipe {
  id: string;
  label: string;
  result: { item: string; count: number };
  ingredients: { item: string; count: number }[];
}

export const RECIPES: Recipe[] = [
  { id: 'planks',        label: 'Wood Planks (x4)',      result: { item: 'planks', count: 4 },          ingredients: [{ item: 'log', count: 1 }] },
  { id: 'stick',         label: 'Sticks (x4)',           result: { item: 'stick', count: 4 },           ingredients: [{ item: 'planks', count: 2 }] },
  { id: 'wood_pickaxe',  label: 'Wood Pickaxe',          result: { item: 'wood_pickaxe', count: 1 },    ingredients: [{ item: 'planks', count: 3 }, { item: 'stick', count: 2 }] },
  { id: 'wood_axe',      label: 'Wood Axe',              result: { item: 'wood_axe', count: 1 },        ingredients: [{ item: 'planks', count: 3 }, { item: 'stick', count: 2 }] },
  { id: 'wood_shovel',   label: 'Wood Shovel',           result: { item: 'wood_shovel', count: 1 },     ingredients: [{ item: 'planks', count: 1 }, { item: 'stick', count: 2 }] },
  { id: 'wood_sword',    label: 'Wood Sword',            result: { item: 'wood_sword', count: 1 },      ingredients: [{ item: 'planks', count: 2 }, { item: 'stick', count: 1 }] },
  { id: 'stone_pickaxe', label: 'Stone Pickaxe',         result: { item: 'stone_pickaxe', count: 1 },   ingredients: [{ item: 'cobblestone', count: 3 }, { item: 'stick', count: 2 }] },
  { id: 'stone_axe',     label: 'Stone Axe',             result: { item: 'stone_axe', count: 1 },       ingredients: [{ item: 'cobblestone', count: 3 }, { item: 'stick', count: 2 }] },
  { id: 'stone_shovel',  label: 'Stone Shovel',          result: { item: 'stone_shovel', count: 1 },    ingredients: [{ item: 'cobblestone', count: 1 }, { item: 'stick', count: 2 }] },
  { id: 'stone_sword',   label: 'Stone Sword',           result: { item: 'stone_sword', count: 1 },     ingredients: [{ item: 'cobblestone', count: 2 }, { item: 'stick', count: 1 }] },
  { id: 'iron_pickaxe',  label: 'Iron Pickaxe',          result: { item: 'iron_pickaxe', count: 1 },    ingredients: [{ item: 'iron_ingot', count: 3 }, { item: 'stick', count: 2 }] },
  { id: 'iron_axe',      label: 'Iron Axe',              result: { item: 'iron_axe', count: 1 },        ingredients: [{ item: 'iron_ingot', count: 3 }, { item: 'stick', count: 2 }] },
  { id: 'iron_shovel',   label: 'Iron Shovel',           result: { item: 'iron_shovel', count: 1 },     ingredients: [{ item: 'iron_ingot', count: 1 }, { item: 'stick', count: 2 }] },
  { id: 'iron_sword',    label: 'Iron Sword',            result: { item: 'iron_sword', count: 1 },      ingredients: [{ item: 'iron_ingot', count: 2 }, { item: 'stick', count: 1 }] },
  { id: 'smelt_iron',    label: 'Smelt Iron Ingot',      result: { item: 'iron_ingot', count: 1 },      ingredients: [{ item: 'raw_iron', count: 1 }, { item: 'planks', count: 1 }] },
];
