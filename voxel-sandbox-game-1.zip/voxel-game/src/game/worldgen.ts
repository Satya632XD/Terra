/**
 * World generation algorithms: features like trees and villages.
 */
import { getBlock, setBlock, getBlockKey, getWorldMap } from './world';
import { CHUNK_MIN_X, CHUNK_MAX_X, CHUNK_MIN_Z, CHUNK_MAX_Z } from './constants';

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function placeFeatures(): void {
  // Trees
  const numTrees = randomInt(8, 12);
  for (let i = 0; i < numTrees; i++) {
    const x = randomInt(CHUNK_MIN_X + 3, CHUNK_MAX_X - 3);
    const z = randomInt(CHUNK_MIN_Z + 3, CHUNK_MAX_Z - 3);
    
    // Check if base is grass/dirt
    if (getBlock(x, 2, z) === 'grass') {
      // Trunk (4 tall)
      for (let y = 3; y <= 6; y++) {
        setBlock(x, y, z, 'log');
      }
      
      // Leaves canopy (3x3x3 sphere-ish around top)
      for (let lx = x - 1; lx <= x + 1; lx++) {
        for (let ly = 6; ly <= 8; ly++) {
          for (let lz = z - 1; lz <= z + 1; lz++) {
            // Cut corners to make it sphere-like
            const dist = Math.abs(lx - x) + Math.abs(ly - 7) + Math.abs(lz - z);
            if (dist <= 2) {
              if (!getBlock(lx, ly, lz)) {
                setBlock(lx, ly, lz, 'leaves');
              }
            }
          }
        }
      }
    }
  }

  // Iron Ore (embedded in stone layer y=0)
  const numOre = randomInt(6, 10);
  for (let i = 0; i < numOre; i++) {
    const x = randomInt(CHUNK_MIN_X, CHUNK_MAX_X);
    const z = randomInt(CHUNK_MIN_Z, CHUNK_MAX_Z);
    setBlock(x, 0, z, 'iron_ore');
  }

  // Diamond Ore (rarer, embedded in the stone layer)
  const numDiamond = randomInt(2, 4);
  for (let i = 0; i < numDiamond; i++) {
    const x = randomInt(CHUNK_MIN_X, CHUNK_MAX_X);
    const z = randomInt(CHUNK_MIN_Z, CHUNK_MAX_Z);
    if (getBlock(x, 0, z) === 'stone') {
      setBlock(x, 0, z, 'diamond_ore');
    }
  }

  // Gravel patches (embedded in the stone layer, purely cosmetic variety)
  const numGravel = randomInt(4, 8);
  for (let i = 0; i < numGravel; i++) {
    const x = randomInt(CHUNK_MIN_X, CHUNK_MAX_X);
    const z = randomInt(CHUNK_MIN_Z, CHUNK_MAX_Z);
    if (getBlock(x, 0, z) === 'stone') {
      setBlock(x, 0, z, 'gravel');
    }
  }

  // Villages
  const numVillages = randomInt(1, 2);
  for (let i = 0; i < numVillages; i++) {
    const vx = randomInt(CHUNK_MIN_X + 6, CHUNK_MAX_X - 6);
    const vz = randomInt(CHUNK_MIN_Z + 6, CHUNK_MAX_Z - 6);
    
    // Prevent spawning right at center (0,0)
    if (Math.abs(vx) < 8 && Math.abs(vz) < 8) continue;
    
    const numHouses = randomInt(2, 3);
    const housePositions: {x: number, z: number}[] = [];
    
    for (let h = 0; h < numHouses; h++) {
      const hx = vx + (h * 8);
      const hz = vz + (randomInt(-3, 3));
      
      if (hx < CHUNK_MIN_X + 3 || hx > CHUNK_MAX_X - 3 || hz < CHUNK_MIN_Z + 3 || hz > CHUNK_MAX_Z - 3) continue;
      housePositions.push({x: hx, z: hz});
      
      // Build House footprint 6 wide(x) x 5 deep(z)
      for (let x = hx; x < hx + 6; x++) {
        for (let z = hz; z < hz + 5; z++) {
          
          // Clear any trees above
          for(let y=3; y<10; y++) {
            if(getBlock(x,y,z)) {
              getWorldMap().delete(getBlockKey(x,y,z));
            }
          }
          
          // Floor
          setBlock(x, 2, z, 'wood');
          
          const isWall = (x === hx || x === hx + 5 || z === hz || z === hz + 4);
          
          if (isWall) {
            // Walls y=3..6
            for (let y = 3; y <= 6; y++) {
              setBlock(x, y, z, 'cobblestone');
            }
          }
        }
      }
      
      // Door (at z = hz, x = hx + 2)
      getWorldMap().delete(getBlockKey(hx + 2, 3, hz));
      getWorldMap().delete(getBlockKey(hx + 2, 4, hz));
      
      // Roof (y=7, covers 6x6, slightly overhanging)
      for (let x = hx - 1; x <= hx + 6; x++) {
        for (let z = hz - 1; z <= hz + 5; z++) {
          setBlock(x, 7, z, 'wood'); // use wood for roof
        }
      }
    }
    
    // Connect houses with paths
    if (housePositions.length > 1) {
      const p1 = housePositions[0];
      for(let i=1; i<housePositions.length; i++) {
        const p2 = housePositions[i];
        let cx = p1.x;
        let cz = p1.z;
        while(cx !== p2.x || cz !== p2.z) {
          if (cx < p2.x) cx++; else if (cx > p2.x) cx--;
          if (cz < p2.z) cz++; else if (cz > p2.z) cz--;
          setBlock(cx, 2, cz, 'grass');
          for(let y=3; y<5; y++) getWorldMap().delete(getBlockKey(cx,y,cz));
        }
      }
    }
  }
}
