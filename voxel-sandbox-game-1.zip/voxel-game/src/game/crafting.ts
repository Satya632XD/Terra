import { RECIPES } from './constants';
import { hasItem, removeItem, addItem } from './inventory';
import { TOOL_DEFS } from './constants';

export function craftItem(recipeId: string): boolean {
  const recipe = RECIPES.find(r => r.id === recipeId);
  if (!recipe) return false;
  // Check all ingredients
  if (!recipe.ingredients.every(ing => hasItem(ing.item, ing.count))) return false;
  // Consume ingredients
  recipe.ingredients.forEach(ing => removeItem(ing.item, ing.count));
  // Add result - if it's a tool, add with durability
  const toolDef = TOOL_DEFS[recipe.result.item];
  if (toolDef) {
    addItem(recipe.result.item, recipe.result.count, toolDef.durability, toolDef.durability);
  } else {
    addItem(recipe.result.item, recipe.result.count);
  }
  return true;
}

export function canCraft(recipeId: string): boolean {
  const recipe = RECIPES.find(r => r.id === recipeId);
  if (!recipe) return false;
  return recipe.ingredients.every(ing => hasItem(ing.item, ing.count));
}
