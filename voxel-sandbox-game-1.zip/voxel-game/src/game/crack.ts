/**
 * 10-stage procedural crack overlay shown on the targeted block while mining.
 * Renders as a semi-transparent mesh slightly larger than the targeted block.
 */
import * as THREE from 'three';

const crackTextures: THREE.CanvasTexture[] = [];

function generateCrackTextures() {
  if (crackTextures.length > 0) return;

  for (let stage = 0; stage < 10; stage++) {
    const canvas = document.createElement('canvas');
    canvas.width = 16;
    canvas.height = 16;
    const ctx = canvas.getContext('2d')!;
    
    // Clear transparent
    ctx.clearRect(0, 0, 16, 16);
    
    if (stage > 0) {
      ctx.strokeStyle = `rgba(0, 0, 0, ${0.4 + (stage / 10) * 0.4})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      
      // Random seed based on stage to make progressive cracks
      // We will just draw random lines emanating from center
      // A simple deterministic pseudo-random approach so cracks build up
      let seed = 12345;
      const random = () => {
        seed = (seed * 9301 + 49297) % 233280;
        return seed / 233280;
      };

      const centerX = 8;
      const centerY = 8;
      
      const numCracks = stage * 2;
      for (let i = 0; i < numCracks; i++) {
        ctx.moveTo(centerX, centerY);
        let x = centerX;
        let y = centerY;
        const segments = 3;
        for (let j = 0; j < segments; j++) {
          x += (random() - 0.5) * 8;
          y += (random() - 0.5) * 8;
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();

      // Additional pixels for heavier cracking
      if (stage > 4) {
        ctx.fillStyle = `rgba(0, 0, 0, ${0.4 + (stage / 10) * 0.4})`;
        for(let i=0; i<stage*3; i++){
          ctx.fillRect(Math.floor(random()*16), Math.floor(random()*16), 1, 1);
        }
      }
    }
    
    const texture = new THREE.CanvasTexture(canvas);
    texture.magFilter = THREE.NearestFilter;
    texture.minFilter = THREE.NearestFilter;
    texture.colorSpace = THREE.SRGBColorSpace;
    crackTextures.push(texture);
  }
}

export class CrackOverlay {
  mesh: THREE.Mesh;

  constructor(scene: THREE.Scene) {
    generateCrackTextures();
    
    const geometry = new THREE.BoxGeometry(1.02, 1.02, 1.02);
    // Use stage 0 initially
    const material = new THREE.MeshBasicMaterial({ 
      map: crackTextures[0], 
      transparent: true, 
      depthWrite: false 
    });
    
    this.mesh = new THREE.Mesh(geometry, material);
    this.mesh.visible = false;
    scene.add(this.mesh);
  }

  update(progress: number, pos: THREE.Vector3 | null) {
    if (!pos || progress <= 0) {
      this.mesh.visible = false;
      return;
    }
    this.mesh.visible = true;
    this.mesh.position.copy(pos);
    
    let stage = Math.floor(progress * 10);
    if (stage > 9) stage = 9;
    if (stage < 0) stage = 0;
    
    (this.mesh.material as THREE.MeshBasicMaterial).map = crackTextures[stage];
  }

  dispose() {
    if (this.mesh.parent) {
      this.mesh.parent.remove(this.mesh);
    }
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.MeshBasicMaterial).dispose();
  }
}
