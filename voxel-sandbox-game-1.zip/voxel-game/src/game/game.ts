/**
 * Main game loop, wiring all modules together.
 */
import * as THREE from 'three';
import { GameRenderer } from './renderer';
import { Player } from './player';
import { InputManager } from './input';
import { generateWorld, setBlock, removeBlock, getBlock } from './world';
import { raycast } from './raycaster';
import { setupMobileControls } from './mobile';
import { HOTBAR_BLOCKS } from './constants';
import { preloadTextures } from './textures';
import { updateMining, subscribeMining } from './mining';
import { DayNightCycle } from './daynight';
import { addItem } from './inventory';

export let currentSelectedBlockIndex = 0;
export let craftingOpen = false;

const selectionListeners: Set<(index: number) => void> = new Set();
const craftingListeners: Set<(open: boolean) => void> = new Set();

export function subscribeToBlockSelection(fn: (index: number) => void) {
  selectionListeners.add(fn);
  return () => { selectionListeners.delete(fn); };
}

export function setSelectedBlockIndex(index: number) {
  currentSelectedBlockIndex = index;
  selectionListeners.forEach(fn => fn(index));
}

export function subscribeCrafting(fn: (open: boolean) => void) {
  craftingListeners.add(fn);
  return () => { craftingListeners.delete(fn); };
}

export function setCraftingOpen(v: boolean): void {
  craftingOpen = v;
  craftingListeners.forEach(fn => fn(v));
}

export async function initGame(canvas: HTMLCanvasElement): Promise<() => void> {
  await preloadTextures(import.meta.env.BASE_URL);

  const renderer = new GameRenderer(canvas);
  const input = new InputManager();
  const player = new Player(renderer.camera, canvas, input);
  const dayNight = new DayNightCycle(renderer.scene, renderer.ambientLight, renderer.sunLight, renderer.camera);
  
  const cleanupMobile = setupMobileControls(input);

  generateWorld();
  renderer.rebuildMeshes();

  const clock = new THREE.Clock();
  let animationFrameId: number;
  let mineProgress = 0;
  let minePos: THREE.Vector3 | null = null;

  function loop() {
    animationFrameId = requestAnimationFrame(loop);
    const delta = Math.min(clock.getDelta(), 0.1);

    // 1. Input & Physics
    player.update(delta, input);

    const digitKeys = ['Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5', 'Digit6', 'Digit7', 'Digit8', 'Digit9'];
    for (let i = 0; i < digitKeys.length && i < HOTBAR_BLOCKS.length; i++) {
      if (input.keys[digitKeys[i]] && currentSelectedBlockIndex !== i) setSelectedBlockIndex(i);
    }

    // 2. Day/Night
    dayNight.update(delta);

    // 2b. Water (depth color, waves, sky-tinted reflection)
    renderer.updateWater(delta, dayNight.getHorizonColor());

    // 3. Raycasting
    const hit = raycast(renderer.camera);
    if (hit) {
      renderer.setOutline(hit.pos);
    } else {
      renderer.setOutline(null);
    }

    // 4. Mining
    const currentBlockType = hit ? getBlock(hit.pos.x, hit.pos.y, hit.pos.z) : undefined;
    if (currentBlockType && hit && input.isHoldingMine) {
      const result = updateMining(true, hit, currentBlockType, delta);
      minePos = hit.pos;
      if (result.mined) {
        removeBlock(hit.pos.x, hit.pos.y, hit.pos.z);
        renderer.rebuildMeshes();
        if (result.droppedItem) addItem(result.droppedItem, 1);
        mineProgress = 0;
        minePos = null;
      }
    } else {
      updateMining(false, null, '', delta);
      mineProgress = 0;
      minePos = null;
    }

    // 5. Placing
    if (hit && input.placeTriggered) {
      const placePos = hit.pos.clone().add(hit.normal);
      const px = Math.floor(player.camera.position.x + 0.5);
      const py = Math.floor(player.camera.position.y - 1.7 + 0.5);
      const py2 = Math.floor(player.camera.position.y + 0.5);
      const pz = Math.floor(player.camera.position.z + 0.5);
      
      const isPlayer = placePos.x === px && placePos.z === pz && (placePos.y === py || placePos.y === py2);
      
      if (!isPlayer && !getBlock(placePos.x, placePos.y, placePos.z)) {
        const blockType = HOTBAR_BLOCKS[currentSelectedBlockIndex];
        if (blockType) {
          setBlock(placePos.x, placePos.y, placePos.z, blockType);
          renderer.rebuildMeshes();
        }
      }
    }

    // 6. Crack overlay updating via event subscriber in renderer
    // (We could manually call updateCrack here but mining.ts already tracks progress. 
    // We'll just subscribe to it in game init, or pass down)
    
    // 7. Crafting panel toggle
    if (input.craftingKeyTriggered) {
      setCraftingOpen(!craftingOpen);
      if (craftingOpen) {
        document.exitPointerLock();
      } else {
        canvas.requestPointerLock();
      }
    }

    input.resetTriggers();

    // 8. Render
    renderer.render();
  }

  // Hook up crack overlay to mining updates
  const unsubMining = subscribeMining((progress: number, pos: THREE.Vector3 | null) => {
    renderer.updateCrack(progress, pos);
  });

  loop();

  return () => {
    cancelAnimationFrame(animationFrameId);
    unsubMining();
    renderer.dispose();
    player.dispose();
    input.dispose();
    cleanupMobile();
  };
}
