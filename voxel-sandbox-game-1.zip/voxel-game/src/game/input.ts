/**
 * Keyboard/mouse/touch input manager.
 */

export class InputManager {
  keys: Record<string, boolean> = {};
  isTouch: boolean = false;
  moveJoystick: { active: boolean; dx: number; dy: number } = { active: false, dx: 0, dy: 0 };
  lookDelta: { dx: number; dy: number } = { dx: 0, dy: 0 };
  
  mineTriggered: boolean = false;
  placeTriggered: boolean = false;
  
  isHoldingMine: boolean = false;
  isHoldingPlace: boolean = false;
  craftingKeyTriggered: boolean = false;

  constructor() {
    this.isTouch = 'ontouchstart' in window;
    
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    window.addEventListener('contextmenu', this.onContextMenu);
  }

  onKeyDown = (e: KeyboardEvent) => {
    this.keys[e.code] = true;
    if (e.code === 'KeyE') {
      this.craftingKeyTriggered = true;
    }
  }

  onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  }

  onMouseDown = (e: MouseEvent) => {
    if (document.pointerLockElement || this.isTouch) {
      if (e.button === 0) {
        this.mineTriggered = true;
        this.isHoldingMine = true;
      }
      if (e.button === 2) {
        this.placeTriggered = true;
        this.isHoldingPlace = true;
      }
    }
  }

  onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.isHoldingMine = false;
    if (e.button === 2) this.isHoldingPlace = false;
  }

  onContextMenu = (e: Event) => {
    e.preventDefault();
  }

  resetTriggers() {
    this.mineTriggered = false;
    this.placeTriggered = false;
    this.craftingKeyTriggered = false;
    this.lookDelta.dx = 0;
    this.lookDelta.dy = 0;
  }

  dispose() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    window.removeEventListener('contextmenu', this.onContextMenu);
  }
}
