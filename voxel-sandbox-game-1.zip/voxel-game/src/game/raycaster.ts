/**
 * Block selection via raycasting, highlight outline.
 */
import * as THREE from 'three';
import { getBlock } from './world';

export interface HitResult {
  pos: THREE.Vector3;
  normal: THREE.Vector3;
}

export function raycast(camera: THREE.PerspectiveCamera, maxDist: number = 5): HitResult | null {
  const start = camera.position.clone();
  const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion).normalize();

  const step = 0.05;
  const pos = start.clone();
  let lastPos = pos.clone();
  
  for (let dist = 0; dist <= maxDist; dist += step) {
    pos.addVectors(start, dir.clone().multiplyScalar(dist));
    const bx = Math.floor(pos.x + 0.5);
    const by = Math.floor(pos.y + 0.5);
    const bz = Math.floor(pos.z + 0.5);
    
    if (getBlock(bx, by, bz)) {
      const lx = Math.floor(lastPos.x + 0.5);
      const ly = Math.floor(lastPos.y + 0.5);
      const lz = Math.floor(lastPos.z + 0.5);
      
      const normal = new THREE.Vector3(lx - bx, ly - by, lz - bz);
      
      if (Math.abs(normal.x) + Math.abs(normal.y) + Math.abs(normal.z) > 1) {
        if (Math.abs(normal.y) > 0) { normal.x = 0; normal.z = 0; }
        else if (Math.abs(normal.x) > 0) { normal.y = 0; normal.z = 0; }
      }
      
      return {
        pos: new THREE.Vector3(bx, by, bz),
        normal
      };
    }
    lastPos.copy(pos);
  }
  return null;
}
