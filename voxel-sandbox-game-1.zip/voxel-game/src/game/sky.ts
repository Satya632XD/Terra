/**
 * Procedural gradient sky dome + stars + glowing sun/moon.
 *
 * This is the single source of truth for sky/horizon color. DayNightCycle
 * feeds it a 0..1 time-of-day value and this module derives the zenith
 * color, horizon color, sun/moon position and visibility, and star
 * opacity. It also exposes the current horizon color so the scene fog
 * can be kept in sync every frame instead of duplicating the color logic.
 */
import * as THREE from 'three';

const SKY_VERTEX_SHADER = /* glsl */ `
  varying vec3 vWorldPosition;
  void main() {
    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
    vWorldPosition = worldPosition.xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const SKY_FRAGMENT_SHADER = /* glsl */ `
  uniform vec3 topColor;
  uniform vec3 horizonColor;
  uniform vec3 bottomColor;
  uniform float offset;
  uniform float exponent;
  varying vec3 vWorldPosition;

  void main() {
    float h = normalize(vWorldPosition + offset).y;
    float t = clamp(h, -1.0, 1.0);
    vec3 color;
    if (t >= 0.0) {
      color = mix(horizonColor, topColor, pow(t, exponent));
    } else {
      color = mix(horizonColor, bottomColor, pow(-t, exponent * 0.6));
    }
    gl_FragColor = vec4(color, 1.0);
  }
`;

const STAR_VERTEX_SHADER = /* glsl */ `
  attribute float size;
  varying float vOpacity;
  uniform float starOpacity;
  void main() {
    vOpacity = starOpacity;
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = size;
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const STAR_FRAGMENT_SHADER = /* glsl */ `
  varying float vOpacity;
  void main() {
    // Soft round point sprite
    vec2 c = gl_PointCoord - vec2(0.5);
    float d = length(c);
    if (d > 0.5) discard;
    float alpha = smoothstep(0.5, 0.0, d) * vOpacity;
    gl_FragColor = vec4(1.0, 1.0, 1.0, alpha);
  }
`;

export interface SkyPalette {
  top: THREE.Color;
  horizon: THREE.Color;
  bottom: THREE.Color;
}

export class Sky {
  private skyMesh: THREE.Mesh;
  private skyMaterial: THREE.ShaderMaterial;
  private starPoints: THREE.Points;
  private starMaterial: THREE.ShaderMaterial;
  private sunSprite: THREE.Sprite;
  private moonSprite: THREE.Sprite;
  private sunMaterial: THREE.SpriteMaterial;
  private moonMaterial: THREE.SpriteMaterial;

  /** Current horizon color — used to keep scene.fog in sync. */
  horizonColor = new THREE.Color('#8FCBEA');

  constructor(private scene: THREE.Scene) {
    // --- Gradient dome ---
    const geometry = new THREE.SphereGeometry(490, 32, 16);
    this.skyMaterial = new THREE.ShaderMaterial({
      vertexShader: SKY_VERTEX_SHADER,
      fragmentShader: SKY_FRAGMENT_SHADER,
      uniforms: {
        topColor: { value: new THREE.Color('#3E7FD9') },
        horizonColor: { value: new THREE.Color('#8FCBEA') },
        bottomColor: { value: new THREE.Color('#1B2A3A') },
        offset: { value: 0 },
        exponent: { value: 0.7 },
      },
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
    });
    this.skyMesh = new THREE.Mesh(geometry, this.skyMaterial);
    this.skyMesh.renderOrder = -1000;
    this.scene.add(this.skyMesh);

    // --- Stars ---
    const starCount = 1200;
    const positions = new Float32Array(starCount * 3);
    const sizes = new Float32Array(starCount);
    for (let i = 0; i < starCount; i++) {
      // Random point on upper hemisphere of a large sphere
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 0.95); // biased away from horizon
      const r = 480;
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.cos(phi);
      const z = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3] = x;
      positions[i * 3 + 1] = Math.abs(y); // keep stars in upper hemisphere
      positions[i * 3 + 2] = z;
      sizes[i] = 1.0 + Math.random() * 2.2;
    }
    const starGeometry = new THREE.BufferGeometry();
    starGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    starGeometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
    this.starMaterial = new THREE.ShaderMaterial({
      vertexShader: STAR_VERTEX_SHADER,
      fragmentShader: STAR_FRAGMENT_SHADER,
      uniforms: { starOpacity: { value: 0 } },
      transparent: true,
      depthWrite: false,
      fog: false,
    });
    this.starPoints = new THREE.Points(starGeometry, this.starMaterial);
    this.starPoints.renderOrder = -999;
    this.scene.add(this.starPoints);

    // --- Sun ---
    this.sunMaterial = new THREE.SpriteMaterial({
      map: makeGlowTexture('#FFF6D8', '#FFD37A'),
      color: 0xffffff,
      transparent: true,
      depthWrite: false,
      fog: false,
    });
    this.sunSprite = new THREE.Sprite(this.sunMaterial);
    this.sunSprite.scale.set(60, 60, 1);
    this.sunSprite.renderOrder = -998;
    this.scene.add(this.sunSprite);

    // --- Moon ---
    this.moonMaterial = new THREE.SpriteMaterial({
      map: makeGlowTexture('#F4F6FF', '#AFC0E8'),
      color: 0xffffff,
      transparent: true,
      depthWrite: false,
      fog: false,
    });
    this.moonSprite = new THREE.Sprite(this.moonMaterial);
    this.moonSprite.scale.set(40, 40, 1);
    this.moonSprite.renderOrder = -998;
    this.scene.add(this.moonSprite);
  }

  /**
   * @param _t           0..1 time of day (currently unused directly — palette/sunDir already reflect it)
   * @param sunDir       normalized sun direction (also used to place sun/moon sprites)
   * @param palette      precomputed top/horizon/bottom colors for this moment
   * @param starOpacity  0..1 how visible stars should be
   * @param cameraPosition  camera world position, so sky/stars/sun/moon always surround the player
   */
  update(
    _t: number,
    sunDir: THREE.Vector3,
    palette: SkyPalette,
    starOpacity: number,
    cameraPosition: THREE.Vector3,
  ): void {
    this.skyMesh.position.copy(cameraPosition);
    this.starPoints.position.copy(cameraPosition);

    this.skyMaterial.uniforms.topColor.value.copy(palette.top);
    this.skyMaterial.uniforms.horizonColor.value.copy(palette.horizon);
    this.skyMaterial.uniforms.bottomColor.value.copy(palette.bottom);
    this.horizonColor.copy(palette.horizon);

    this.starMaterial.uniforms.starOpacity.value = starOpacity;

    const dist = 400;
    this.sunSprite.position.copy(cameraPosition).addScaledVector(sunDir, dist);
    this.moonSprite.position.copy(cameraPosition).addScaledVector(sunDir, -dist);

    // Fade sun/moon near/below horizon so they don't pop through the ground plane
    const sunVisibility = THREE.MathUtils.smoothstep(sunDir.y, -0.05, 0.08);
    const moonVisibility = THREE.MathUtils.smoothstep(-sunDir.y, -0.05, 0.08);
    this.sunMaterial.opacity = sunVisibility;
    this.moonMaterial.opacity = moonVisibility;
  }

  dispose(): void {
    this.scene.remove(this.skyMesh, this.starPoints, this.sunSprite, this.moonSprite);
    this.skyMesh.geometry.dispose();
    this.skyMaterial.dispose();
    this.starPoints.geometry.dispose();
    this.starMaterial.dispose();
    this.sunMaterial.map?.dispose();
    this.sunMaterial.dispose();
    this.moonMaterial.map?.dispose();
    this.moonMaterial.dispose();
  }
}

/** Small radial-gradient glow sprite texture, generated on a canvas. */
function makeGlowTexture(coreColor: string, glowColor: string): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  gradient.addColorStop(0, coreColor);
  gradient.addColorStop(0.35, glowColor);
  gradient.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, size, size);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
