/**
 * Three.js scene, setup, and mesh rebuild on world change.
 */
import * as THREE from 'three';
import { BlockType } from './constants';
import { getTexture } from './textures';
import { getWorldMap, getBlock } from './world';
import { CrackOverlay } from './crack';
import { Water } from './water';

const FACES: Array<{ dir: [number, number, number]; name: 'top' | 'side' | 'bottom' }> = [
  { dir: [1, 0, 0], name: 'side' },
  { dir: [-1, 0, 0], name: 'side' },
  { dir: [0, 1, 0], name: 'top' },
  { dir: [0, -1, 0], name: 'bottom' },
  { dir: [0, 0, 1], name: 'side' },
  { dir: [0, 0, -1], name: 'side' }
];

export class GameRenderer {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  meshGroup: THREE.Group;
  materials: Map<BlockType, THREE.Material[]>;
  outlineMesh: THREE.LineSegments;
  crackOverlay: CrackOverlay;
  water: Water;
  ambientLight: THREE.AmbientLight;
  sunLight: THREE.DirectionalLight;

  constructor(canvas: HTMLCanvasElement) {
    this.scene = new THREE.Scene();
    // Sky background/fog color is now owned entirely by DayNightCycle + Sky
    // (see daynight.ts) so there is a single source of truth for both.

    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      failIfMajorPerformanceCaveat: false,
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setClearColor(0x8fcbea, 1);

    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(this.ambientLight);

    this.sunLight = new THREE.DirectionalLight(0xffffff, 0.8);
    this.sunLight.position.set(10, 20, 10);
    this.scene.add(this.sunLight);

    this.meshGroup = new THREE.Group();
    this.scene.add(this.meshGroup);

    this.materials = new Map();

    const edgeGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.005, 1.005, 1.005));
    const edgeMat = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
    this.outlineMesh = new THREE.LineSegments(edgeGeo, edgeMat);
    this.outlineMesh.visible = false;
    this.scene.add(this.outlineMesh);

    this.crackOverlay = new CrackOverlay(this.scene);

    // Water surface sits just below the sand/grass top (block top face is at
    // y = 2.5) so it visibly laps at the beach ring around the island.
    this.water = new Water(this.scene, 1.65);

    window.addEventListener('resize', this.onResize);
  }

  getMaterials(blockType: BlockType): THREE.Material[] {
    if (!this.materials.has(blockType)) {
      const alphaTest = blockType === 'leaves' ? 0.5 : 0;
      const transparent = blockType === 'leaves';
      this.materials.set(blockType, [
        new THREE.MeshLambertMaterial({ map: getTexture(blockType, 'side'), alphaTest, transparent }),
        new THREE.MeshLambertMaterial({ map: getTexture(blockType, 'side'), alphaTest, transparent }),
        new THREE.MeshLambertMaterial({ map: getTexture(blockType, 'top'), alphaTest, transparent }),
        new THREE.MeshLambertMaterial({ map: getTexture(blockType, 'bottom'), alphaTest, transparent }),
        new THREE.MeshLambertMaterial({ map: getTexture(blockType, 'side'), alphaTest, transparent }),
        new THREE.MeshLambertMaterial({ map: getTexture(blockType, 'side'), alphaTest, transparent }),
      ]);
    }
    return this.materials.get(blockType)!;
  }

  rebuildMeshes() {
    this.meshGroup.clear();

    const geometry = new THREE.BoxGeometry(1, 1, 1);
    
    // Group blocks by type
    const blocksByType = new Map<BlockType, Array<[number, number, number]>>();
    const world = getWorldMap();

    for (const [key, type] of world.entries()) {
      if (!blocksByType.has(type)) {
        blocksByType.set(type, []);
      }
      const [x, y, z] = key.split(',').map(Number);
      
      // Face culling
      let isHidden = true;
      for (const face of FACES) {
        const nx = x + face.dir[0];
        const ny = y + face.dir[1];
        const nz = z + face.dir[2];
        const neighbor = getBlock(nx, ny, nz);
        // If neighbor is transparent, block is not hidden
        if (!neighbor || neighbor === 'leaves') {
          isHidden = false;
          break;
        }
      }

      if (!isHidden) {
        blocksByType.get(type)!.push([x, y, z]);
      }
    }

    const dummy = new THREE.Object3D();

    for (const [type, positions] of blocksByType.entries()) {
      if (positions.length === 0) continue;
      const instancedMesh = new THREE.InstancedMesh(geometry, this.getMaterials(type), positions.length);
      instancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      
      for (let i = 0; i < positions.length; i++) {
        const [x, y, z] = positions[i];
        dummy.position.set(x, y, z);
        dummy.updateMatrix();
        instancedMesh.setMatrixAt(i, dummy.matrix);
      }
      instancedMesh.instanceMatrix.needsUpdate = true;
      this.meshGroup.add(instancedMesh);
    }
  }

  setOutline(position: THREE.Vector3 | null) {
    if (position) {
      this.outlineMesh.position.copy(position);
      this.outlineMesh.visible = true;
    } else {
      this.outlineMesh.visible = false;
    }
  }

  updateCrack(progress: number, pos: THREE.Vector3 | null) {
    this.crackOverlay.update(progress, pos);
  }

  updateWater(delta: number, skyHorizonColor: THREE.Color) {
    this.water.setSkyTint(skyHorizonColor);
    this.water.update(delta);
  }

  onResize = () => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    window.removeEventListener('resize', this.onResize);
    this.crackOverlay.dispose();
    this.water.dispose();
    this.renderer.dispose();
  }
}
