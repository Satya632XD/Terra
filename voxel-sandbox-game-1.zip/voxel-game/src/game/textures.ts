/**
 * Runtime canvas-generated textures for each block face.
 */
import * as THREE from 'three';
import { BlockType, BLOCK_COLORS } from './constants';

const textures = new Map<string, THREE.Texture>();
const preloadedPngs = new Map<string, THREE.Texture>();

export async function preloadTextures(basePath: string): Promise<void> {
  const loader = new THREE.TextureLoader();
  const maps: Record<string, string> = {
    'grass-top': `${basePath}textures/grass_top.png`,
    'grass-side': `${basePath}textures/grass_side.png`,
    'dirt': `${basePath}textures/dirt.png`,
    'stone': `${basePath}textures/stone.png`,
    'log-top': `${basePath}textures/wood_top.png`,
    'log-side': `${basePath}textures/wood_side.png`,
    'leaves': `${basePath}textures/leaf.png`,
    'planks': `${basePath}textures/wood_plank.png`,
    'cobblestone': `${basePath}textures/cobblestone.png`,
    'bedrock': `${basePath}textures/bedrock.png`,
    'gravel': `${basePath}textures/gravel.png`,
    'sand': `${basePath}textures/sand.png`,
    'diamond_ore': `${basePath}textures/diamond_ore.png`,
  };

  const promises = Object.entries(maps).map(async ([key, url]) => {
    try {
      const tex = await loader.loadAsync(url);
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;
      tex.colorSpace = THREE.SRGBColorSpace;
      preloadedPngs.set(key, tex);
    } catch (e) {
      console.warn(`Failed to load texture ${url}`);
    }
  });

  await Promise.all(promises);
}

function generateNoise(ctx: CanvasRenderingContext2D, width: number, height: number, color: string, intensity: number) {
  ctx.fillStyle = color;
  for (let i = 0; i < width * height * intensity; i++) {
    const x = Math.floor(Math.random() * width);
    const y = Math.floor(Math.random() * height);
    ctx.fillRect(x, y, 1, 1);
  }
}

function createTexture(block: BlockType, face: 'top' | 'side' | 'bottom'): THREE.Texture {
  // Check if we have a preloaded PNG
  let pngKey = block.toString();
  if (block === 'grass' && face === 'top') pngKey = 'grass-top';
  if (block === 'grass' && face === 'side') pngKey = 'grass-side';
  if (block === 'grass' && face === 'bottom') pngKey = 'dirt';
  if (block === 'log' && (face === 'top' || face === 'bottom')) pngKey = 'log-top';
  if (block === 'log' && face === 'side') pngKey = 'log-side';
  if (block === 'wood') pngKey = 'planks'; // map wood block to planks texture
  // cobblestone, bedrock, gravel, sand, diamond_ore use their own PNG (same on all faces),
  // matched below via the `preloadedPngs.has(block)` fallback.

  if (preloadedPngs.has(pngKey)) {
    return preloadedPngs.get(pngKey)!;
  }
  
  if (preloadedPngs.has(block)) {
    return preloadedPngs.get(block)!;
  }

  // Fallback to canvas generation
  const canvas = document.createElement('canvas');
  canvas.width = 16;
  canvas.height = 16;
  const ctx = canvas.getContext('2d')!;

  const colors = BLOCK_COLORS[block];
  const color = colors[face] || '#FF00FF';

  ctx.fillStyle = color;
  ctx.fillRect(0, 0, 16, 16);

  if (block === 'grass') {
    if (face === 'top') {
      generateNoise(ctx, 16, 16, '#4A7A2C', 0.2);
    } else if (face === 'side') {
      ctx.fillStyle = BLOCK_COLORS.grass.top;
      ctx.fillRect(0, 0, 16, 3);
      generateNoise(ctx, 16, 16, '#6A4C2A', 0.1);
    }
  } else if (block === 'dirt') {
    generateNoise(ctx, 16, 16, '#6A4C2A', 0.1);
  } else if (block === 'stone') {
    generateNoise(ctx, 16, 16, '#777777', 0.2);
    ctx.fillStyle = '#666666';
    ctx.fillRect(4, 0, 1, 4);
    ctx.fillRect(5, 4, 3, 1);
    ctx.fillRect(8, 5, 1, 6);
  } else if (block === 'wood') {
    if (face === 'top' || face === 'bottom') {
      ctx.strokeStyle = '#A8894E';
      ctx.lineWidth = 1;
      for (let r = 2; r <= 10; r += 2) {
        ctx.beginPath();
        ctx.arc(8, 8, r, 0, Math.PI * 2);
        ctx.stroke();
      }
    } else {
      ctx.fillStyle = '#9B7350';
      for (let x = 1; x < 16; x += 3) {
        ctx.fillRect(x, 0, 1, 16);
      }
    }
  } else if (block === 'brick') {
    ctx.fillStyle = '#C8A85A';
    for (let y = 3; y < 16; y += 4) {
      ctx.fillRect(0, y, 16, 1);
    }
    for (let y = 0; y < 16; y += 4) {
      const offset = (y / 4) % 2 === 0 ? 4 : 8;
      for (let x = offset; x < 16; x += 8) {
        ctx.fillRect(x, y, 1, 4);
      }
    }
  } else if (block === 'cobblestone') {
    // Irregular cell pattern
    generateNoise(ctx, 16, 16, '#777777', 0.2);
    ctx.strokeStyle = '#777777';
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, 8, 8);
    ctx.strokeRect(8, 0, 8, 10);
    ctx.strokeRect(0, 8, 6, 8);
    ctx.strokeRect(6, 10, 10, 6);
  } else if (block === 'iron_ore') {
    // Stone base
    generateNoise(ctx, 16, 16, '#777777', 0.2);
    ctx.fillStyle = '#666666';
    ctx.fillRect(4, 0, 1, 4);
    ctx.fillRect(5, 4, 3, 1);
    ctx.fillRect(8, 5, 1, 6);
    // Iron veins
    ctx.fillStyle = '#C8B87A';
    for (let i = 0; i < 8; i++) {
      ctx.fillRect(Math.floor(Math.random() * 15), Math.floor(Math.random() * 15), 2, 2);
    }
  } else if (block === 'bedrock') {
    generateNoise(ctx, 16, 16, '#3A3A3A', 0.3);
    generateNoise(ctx, 16, 16, '#5A5A5A', 0.15);
  } else if (block === 'gravel') {
    generateNoise(ctx, 16, 16, '#6E6E6C', 0.25);
    generateNoise(ctx, 16, 16, '#B0AFAC', 0.15);
  } else if (block === 'sand') {
    generateNoise(ctx, 16, 16, '#D8CB90', 0.15);
    generateNoise(ctx, 16, 16, '#F0E4B0', 0.1);
  } else if (block === 'diamond_ore') {
    generateNoise(ctx, 16, 16, '#777777', 0.2);
    ctx.fillStyle = '#666666';
    ctx.fillRect(4, 0, 1, 4);
    ctx.fillRect(5, 4, 3, 1);
    ctx.fillRect(8, 5, 1, 6);
    ctx.fillStyle = '#5FE0E0';
    for (let i = 0; i < 8; i++) {
      ctx.fillRect(Math.floor(Math.random() * 15), Math.floor(Math.random() * 15), 2, 2);
    }
  } else if (block === 'leaves') {
    // If procedural fallback needed, punch holes
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, 16, 16);
    ctx.clearRect(2, 2, 2, 2);
    ctx.clearRect(10, 4, 3, 2);
    ctx.clearRect(4, 10, 2, 3);
    ctx.clearRect(12, 12, 2, 2);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function getTexture(blockType: BlockType, face: 'top' | 'side' | 'bottom'): THREE.Texture {
  const key = `${blockType}-${face}`;
  if (!textures.has(key)) {
    textures.set(key, createTexture(blockType, face));
  }
  return textures.get(key)!;
}
