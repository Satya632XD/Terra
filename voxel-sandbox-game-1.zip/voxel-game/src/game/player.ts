/**
 * Player camera, movement, collision and gravity.
 */
import * as THREE from 'three';
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';
import { InputManager } from './input';
import { getBlock } from './world';

export class Player {
  camera: THREE.PerspectiveCamera;
  controls: PointerLockControls;
  velocity = new THREE.Vector3();
  direction = new THREE.Vector3();
  onGround = false;

  speed = 5.0;
  gravity = 20.0;
  jumpForce = 8.0;

  constructor(camera: THREE.PerspectiveCamera, domElement: HTMLElement, input: InputManager) {
    this.camera = camera;
    this.camera.position.set(0, 5, 5);
    this.camera.lookAt(0, 5, 0);

    this.controls = new PointerLockControls(this.camera, domElement);

    if (!input.isTouch) {
      domElement.addEventListener('click', () => {
        if (!this.controls.isLocked) {
          this.controls.lock();
        }
      });
    }
  }

  checkCollision(pos: THREE.Vector3): boolean {
    const hx = 0.3;
    const hz = 0.3;
    const height = 1.7;
    const yOffsets = [0, height / 2, height];

    for (const yo of yOffsets) {
      for (const xo of [-hx, hx]) {
        for (const zo of [-hz, hz]) {
          const x = Math.floor(pos.x + xo + 0.5);
          const y = Math.floor(pos.y - 1.7 + yo + 0.5); 
          const z = Math.floor(pos.z + zo + 0.5);
          if (getBlock(x, y, z)) return true;
        }
      }
    }
    return false;
  }

  update(delta: number, input: InputManager) {
    if (input.isTouch) {
      const euler = new THREE.Euler(0, 0, 0, 'YXZ');
      euler.setFromQuaternion(this.camera.quaternion);
      euler.y -= input.lookDelta.dx * 0.005;
      euler.x -= input.lookDelta.dy * 0.005;
      euler.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, euler.x));
      this.camera.quaternion.setFromEuler(euler);
    }

    if (!this.controls.isLocked && !input.isTouch) return;

    this.direction.z = Number(input.keys['KeyS'] || input.keys['ArrowDown'] ? 1 : 0) - Number(input.keys['KeyW'] || input.keys['ArrowUp'] ? 1 : 0);
    this.direction.x = Number(input.keys['KeyD'] || input.keys['ArrowRight'] ? 1 : 0) - Number(input.keys['KeyA'] || input.keys['ArrowLeft'] ? 1 : 0);
    
    if (input.moveJoystick.active) {
      this.direction.x = input.moveJoystick.dx;
      this.direction.z = input.moveJoystick.dy;
    }

    this.direction.normalize();

    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    forward.y = 0;
    forward.normalize();

    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
    right.y = 0;
    right.normalize();

    const moveVector = new THREE.Vector3()
      .addScaledVector(right, this.direction.x * this.speed * delta)
      .addScaledVector(forward, -this.direction.z * this.speed * delta);

    this.velocity.y -= this.gravity * delta;
    
    if (input.keys['Space'] && this.onGround) {
      this.velocity.y = this.jumpForce;
      this.onGround = false;
    }

    // Try moving X
    this.camera.position.x += moveVector.x;
    if (this.checkCollision(this.camera.position)) {
      this.camera.position.x -= moveVector.x;
    }

    // Try moving Z
    this.camera.position.z += moveVector.z;
    if (this.checkCollision(this.camera.position)) {
      this.camera.position.z -= moveVector.z;
    }

    // Try moving Y
    this.camera.position.y += this.velocity.y * delta;
    if (this.checkCollision(this.camera.position)) {
      if (this.velocity.y < 0) {
        this.onGround = true;
      }
      this.camera.position.y -= this.velocity.y * delta;
      this.velocity.y = 0;
    } else {
      this.onGround = false;
    }
  }

  dispose() {
    this.controls.dispose();
  }
}
