import React, { useEffect, useState } from 'react';
import { getInventory, getHeldTool, subscribeInventory } from './game/inventory';

export default function InventoryBar() {
  const [, setHash] = useState(0);

  useEffect(() => {
    return subscribeInventory(() => setHash(h => h + 1));
  }, []);

  const inventory = getInventory();
  const heldTool = getHeldTool();

  const getCount = (item: string) => {
    return inventory.filter(i => i.item === item).reduce((sum, i) => sum + i.count, 0);
  };

  const trackingItems = ['log', 'planks', 'stick', 'raw_iron', 'iron_ingot', 'cobblestone'];

  return (
    <div style={{
      position: 'absolute',
      bottom: '100px', // above hotbar
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '8px',
      pointerEvents: 'none',
      userSelect: 'none',
      zIndex: 10,
      color: 'white',
      textShadow: '1px 1px 2px black',
      fontFamily: 'sans-serif'
    }}>
      {/* Held Tool Info */}
      {heldTool && (
        <div style={{
          backgroundColor: 'rgba(0,0,0,0.6)',
          padding: '6px 12px',
          borderRadius: '20px',
          fontSize: '14px',
          fontWeight: 'bold',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{ textTransform: 'capitalize' }}>{heldTool.item.replace('_', ' ')}</span>
          {heldTool.maxDurability && (
            <div style={{ width: '60px', height: '6px', backgroundColor: '#333', borderRadius: '3px', overflow: 'hidden' }}>
              <div style={{
                height: '100%',
                backgroundColor: heldTool.durability! / heldTool.maxDurability! > 0.3 ? '#4CAF50' : '#FF5252',
                width: `${Math.max(0, Math.min(100, (heldTool.durability! / heldTool.maxDurability!) * 100))}%`
              }} />
            </div>
          )}
        </div>
      )}

      {/* Materials */}
      <div style={{ display: 'flex', gap: '8px' }}>
        {trackingItems.map(item => {
          const count = getCount(item);
          if (count === 0) return null;
          return (
            <div key={item} style={{
              backgroundColor: 'rgba(0,0,0,0.4)',
              padding: '4px 8px',
              borderRadius: '4px',
              fontSize: '12px',
              display: 'flex',
              gap: '4px'
            }}>
              <span style={{ color: '#DDD' }}>{item.replace('_', ' ')}</span>
              <span style={{ fontWeight: 'bold' }}>{count}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
