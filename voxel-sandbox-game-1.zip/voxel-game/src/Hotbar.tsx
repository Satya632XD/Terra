import { useEffect, useState } from 'react';
import { HOTBAR_BLOCKS, BLOCK_COLORS } from './game/constants';
import { currentSelectedBlockIndex, subscribeToBlockSelection, setSelectedBlockIndex } from './game/game';
import { getInventory, subscribeInventory, equipTool, getHeldToolIndex } from './game/inventory';

export default function Hotbar() {
  const [selectedIndex, setSelectedIndex] = useState(currentSelectedBlockIndex);
  const [, setHash] = useState(0);

  useEffect(() => {
    return subscribeToBlockSelection(setSelectedIndex);
  }, []);

  useEffect(() => {
    return subscribeInventory(() => setHash(h => h + 1));
  }, []);

  const inventory = getInventory();
  const heldToolIndex = getHeldToolIndex();

  const toolItems = inventory.map((item, idx) => ({ item, idx })).filter(x => x.item.durability !== undefined);

  return (
    <div style={{
      position: 'absolute',
      bottom: '20px',
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      gap: '20px',
      pointerEvents: 'auto',
      userSelect: 'none',
      zIndex: 10
    }}>
      {/* Tool Slots */}
      <div style={{ display: 'flex', gap: '10px' }}>
        {toolItems.length === 0 && (
          <div style={{
            width: '64px', height: '64px', backgroundColor: 'rgba(0,0,0,0.5)',
            border: '3px solid #333', borderRadius: '8px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#666', fontSize: '10px', textAlign: 'center', padding: '4px'
          }}>
            No Tool
          </div>
        )}
        {toolItems.map(({ item, idx }) => (
          <div
            key={idx}
            onClick={() => equipTool(heldToolIndex === idx ? null : idx)}
            style={{
              width: '64px', height: '64px', backgroundColor: 'rgba(0,0,0,0.7)',
              border: heldToolIndex === idx ? '3px solid #4CAF50' : '3px solid #333',
              borderRadius: '8px', display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
              boxShadow: '0 4px 6px rgba(0,0,0,0.3)', color: 'white',
              fontWeight: 'bold', fontSize: '10px', textTransform: 'capitalize',
              textShadow: '1px 1px 2px black', textAlign: 'center', padding: '4px'
            }}
          >
            {item.item.replace('_', ' ')}
            <div style={{ marginTop: 'auto', width: '100%', height: '4px', backgroundColor: '#333', borderRadius: '2px' }}>
              <div style={{
                height: '100%', backgroundColor: (item.durability! / item.maxDurability!) > 0.3 ? '#4CAF50' : '#FF5252',
                width: `${(item.durability! / item.maxDurability!) * 100}%`
              }} />
            </div>
          </div>
        ))}
      </div>

      <div style={{ width: '2px', backgroundColor: '#444' }} />

      {/* Block Slots */}
      <div style={{ display: 'flex', gap: '10px' }}>
        {HOTBAR_BLOCKS.map((block, idx) => (
          <div
            key={block}
            onClick={() => setSelectedBlockIndex(idx)}
            style={{
              width: '64px',
              height: '64px',
              backgroundColor: BLOCK_COLORS[block].side,
              border: selectedIndex === idx ? '3px solid white' : '3px solid #333',
              borderRadius: '8px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              boxShadow: '0 4px 6px rgba(0,0,0,0.3)',
              color: 'white',
              fontWeight: 'bold',
              fontSize: '12px',
              textTransform: 'capitalize',
              textShadow: '1px 1px 2px black'
            }}
          >
            <span style={{ fontSize: '10px', color: '#ccc', marginBottom: '4px' }}>{idx + 1}</span>
            {block}
          </div>
        ))}
      </div>
    </div>
  );
}
