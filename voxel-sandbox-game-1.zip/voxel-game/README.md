# Voxel Sandbox Game — Minecraft-Style Survival Prototype

A browser-based 3D voxel survival game built with **React**, **TypeScript**, and **Three.js**.  
Mine blocks with timed progress, craft tools, explore a world with trees and villages, and survive day and night.

---

## Controls

| Action | Desktop | Mobile |
|---|---|---|
| Move | WASD | Left joystick |
| Look | Mouse (pointer lock) | Right-side drag |
| Jump | Space | Jump button |
| Mine block | Hold Left-click | Mine button |
| Place block | Right-click | Place button |
| Switch block 1/2/3 | 1 / 2 / 3 keys | Tap hotbar slot |
| Open/close crafting | E | — |

---

## Directory Structure

```
artifacts/voxel-game/
├── README.md                        ← you are here
├── package.json                     ← dependencies: three, react, typescript, vite
├── tsconfig.json                    ← TypeScript config
├── vite.config.ts                   ← Vite dev server + base-path config
│
├── public/
│   └── textures/                    ← PNG block textures (loaded at runtime)
│       ├── grass-top.png            ← bright green pixel tiles
│       ├── grass-side.png           ← green-strip + dirt side
│       ├── dirt.png                 ← brown tile pattern
│       ├── stone.png                ← grey stone pattern
│       ├── log-top.png              ← wood-ring end grain
│       ├── log-side.png             ← dark bark side
│       ├── leaves.png               ← green leaf canopy
│       └── planks.png               ← tan wood plank strips
│
└── src/
    ├── main.tsx                     ← React entry point
    ├── index.css                    ← Global styles (full-screen canvas reset)
    │
    ├── App.tsx                      ← Root component: async game init, overlays
    ├── Hotbar.tsx                   ← Bottom hotbar (3 placeable block slots)
    ├── InventoryBar.tsx             ← Tool + material count display above hotbar
    ├── CraftingPanel.tsx            ← Crafting UI panel (press E to open)
    │
    └── game/                        ← All Three.js game logic — framework-free modules
        ├── constants.ts             ← Block types, tool defs, hardness table, recipes
        ├── textures.ts              ← PNG + procedural texture loader/generator
        ├── world.ts                 ← Sparse voxel map: getBlock/setBlock/removeBlock
        ├── worldgen.ts              ← Trees, iron ore, village structure generation
        ├── renderer.ts              ← InstancedMesh scene, face-culling, crack support
        ├── crack.ts                 ← 10-stage procedural crack overlay mesh
        ├── player.ts                ← PointerLockControls, WASD, jump, gravity, AABB
        ├── input.ts                 ← Keyboard/mouse event manager, hold-state flags
        ├── raycaster.ts             ← DDA ray traversal, block hit + face normal
        ├── mining.ts                ← Timed mining state machine, tool-speed/tier logic
        ├── inventory.ts             ← Inventory store: items, tools, durability
        ├── crafting.ts              ← Recipe evaluation and crafting execution
        ├── daynight.ts              ← Day/night cycle (7-min day, 3-min night)
        ├── mobile.ts                ← Touch joystick, look drag, Mine/Place/Jump buttons
        └── game.ts                  ← Main requestAnimationFrame loop, wires all modules
```

---

## Module Overview

### `constants.ts`
Single source of truth for all game data:
- **`BlockType`** — `grass | dirt | stone | wood | brick | log | leaves | cobblestone | iron_ore`
- **`BLOCK_HARDNESS`** — seconds to break with bare hands per block type
- **`BLOCK_CATEGORY`** — which tool category gives a speed bonus (`dirt | stone | wood | generic`)
- **`BLOCK_REQUIRED_TIER`** — minimum tool tier needed for the block to drop an item
- **`BLOCK_DROPS`** — override drop (e.g. `stone → cobblestone`, `iron_ore → raw_iron`)
- **`TOOL_DEFS`** — 12 tools (pickaxe/axe/shovel/sword × wood/stone/iron) with durability and mining speed
- **`RECIPES`** — full crafting recipe list (logs → planks → sticks → tools → iron ingot)

### `textures.ts`
Async PNG loading via `THREE.TextureLoader` with procedural canvas fallbacks:
- `preloadTextures(basePath)` — loads all PNGs before the game starts
- `getTexture(blockType, face)` — returns the correct `THREE.Texture` for any block face
- All textures use `NearestFilter` for crisp pixel-art rendering

### `world.ts`
World state as `Map<"x,y,z", BlockType>`:
- `generateWorld()` — flat 32×32 terrain (stone Y=0, dirt Y=1, grass Y=2) then calls worldgen

### `worldgen.ts`
Procedural world features:
- **Trees** — 8–12 random trees: 4-block log trunk + sphere-ish leaf canopy
- **Iron ore** — 6–10 `iron_ore` blocks embedded in stone layer (Y=0)
- **Villages** — 1–2 villages of 2–3 cobblestone houses with wood roofs, open doorways, and cleared paths between them

### `renderer.ts`
- One `THREE.InstancedMesh` per block type for efficient GPU instancing
- Face-culling skips internal faces between solid adjacent blocks
- `rebuildMeshes()` — regenerates all instances on world change
- `updateCrack(progress, pos)` — delegates to the crack overlay
- Ambient + directional lights (adjusted by day/night cycle)

### `crack.ts`
10-stage block-breaking overlay:
- Generates 10 canvas textures at init (transparent background, increasingly dense black cracks)
- Renders as a `1.02×1.02×1.02` transparent mesh over the targeted block
- Stage = `Math.floor(progress × 10)`, hidden when not mining

### `player.ts`
- `PointerLockControls` for mouse look
- Velocity-based movement with 20 units/s² gravity
- Jump impulse; AABB checks against world blocks for collision

### `input.ts`
Central event hub:
- `keys` — held key map
- `isHoldingMine` / `isHoldingPlace` — mouse button hold state (cleared on mouseup)
- `mineTriggered` / `placeTriggered` — one-frame triggers
- `craftingKeyTriggered` — E key, one-shot
- `resetTriggers()` — clears one-shot flags each frame end

### `raycaster.ts`
DDA ray traversal up to 5 units from camera, returning `{ pos: Vector3, normal: Vector3 }` for the first solid block hit.

### `mining.ts`
Timed mining state machine:
1. While LMB held and target is stable, accumulate `progress += effectiveSpeed × delta`
2. `effectiveSpeed` = `1 / hardness` × tool speed multiplier (3× if correct tool category)
3. On `progress >= 1`: check required tier → apply drops → call `damageHeldTool()` → return mined result
4. Progress resets if mouse released, target changes, or raycast misses

### `inventory.ts`
Singleton inventory store:
- `addItem(item, count, durability?)` — stacks matching items
- `removeItem(item, count)` — consumes items for crafting
- `equipTool(index)` / `getHeldTool()` — tool equip state
- `damageHeldTool()` — decrements durability, removes tool if at 0
- `subscribeInventory(fn)` — React components listen for UI updates

### `crafting.ts`
- `canCraft(recipeId)` — checks inventory against recipe ingredients
- `craftItem(recipeId)` — consumes ingredients, adds result (with durability for tools)

### `daynight.ts`
10-minute full cycle (7-min day, 3-min night):
- Smoothly lerps sky color: dawn orange → day blue → dusk orange → night dark blue
- Adjusts ambient + directional light intensity and sun position each frame
- Exposes `getTimeString()` for HH:MM clock display

### `mobile.ts`
Touch-device controls (hidden on desktop):
- Left-side virtual joystick for movement
- Right-area drag for camera look
- Mine / Place / Jump overlay buttons

### `game.ts`
Main loop (`requestAnimationFrame`) — phases each frame:
1. Player physics + hotkey handling
2. Day/night update
3. Raycasting
4. Mining state machine (replaces instant mine)
5. Block placement (right-click, still instant)
6. Crack overlay update
7. Block outline update
8. Render

---

## Hardness & Tool Tier Reference

| Block | Hardness (s) | Category | Required tier to drop |
|---|---|---|---|
| Grass | 0.9 | dirt | — |
| Dirt | 0.75 | dirt | — |
| Stone | 7.5 | stone | wood pickaxe |
| Cobblestone | 10.0 | stone | — |
| Brick | 10.0 | stone | wood pickaxe |
| Log | 3.0 | wood | — |
| Leaves | 0.3 | wood | — |
| Wood (planks) | 3.0 | wood | — |
| Iron Ore | 15.0 | stone | stone pickaxe |

Tool speed multiplier: **3×** when tool category matches block category (pickaxe↔stone, axe↔wood, shovel↔dirt).

---

## Crafting Recipes

| Output | Ingredients |
|---|---|
| Wood Planks ×4 | 1 Log |
| Sticks ×4 | 2 Planks |
| Wood Pickaxe | 3 Planks + 2 Sticks |
| Wood Axe | 3 Planks + 2 Sticks |
| Wood Shovel | 1 Plank + 2 Sticks |
| Wood Sword | 2 Planks + 1 Stick |
| Stone Pickaxe | 3 Cobblestone + 2 Sticks |
| Stone Axe | 3 Cobblestone + 2 Sticks |
| Stone Shovel | 1 Cobblestone + 2 Sticks |
| Stone Sword | 2 Cobblestone + 1 Stick |
| Iron Pickaxe | 3 Iron Ingot + 2 Sticks |
| Iron Axe | 3 Iron Ingot + 2 Sticks |
| Iron Shovel | 1 Iron Ingot + 2 Sticks |
| Iron Sword | 2 Iron Ingot + 1 Stick |
| Iron Ingot (smelt) | 1 Raw Iron + 1 Plank (fuel) |

---

## Running Locally

```bash
# Install dependencies
pnpm install

# Start dev server
pnpm --filter @workspace/voxel-game run dev
```

Requires Node.js 20+ and pnpm. Open `http://localhost:<PORT>` in a WebGL-capable browser (Chrome or Firefox recommended).

---

## Extending the Game

- **Add a new block type** — add to `BlockType` in `constants.ts`, add hardness/category/drop entries, add a texture case in `textures.ts`.
- **New tool tier** — add entries to `TOOL_DEFS` and `RECIPES` in `constants.ts`.
- **Larger world** — change `WORLD_SIZE` in `constants.ts` (larger = more instances, consider chunk streaming for big worlds).
- **Save/load** — serialise the `worldMap` from `world.ts` and inventory from `inventory.ts` to `localStorage`.
- **Mobs** — spawn entities in `worldgen.ts` and add an AI update step in `game.ts`'s main loop.
- **Rebalance hardness/tools** — edit `BLOCK_HARDNESS` and `TOOL_DEFS` in `constants.ts`; all mining math reads from there.
